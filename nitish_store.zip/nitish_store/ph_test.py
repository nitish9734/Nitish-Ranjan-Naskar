import os

def login():
    print("\n\t _ _ Login _ _")
    l1=input("Enter your Phone no. : ")
    l2=input("Enter password : ")
    (c1,c2)=(0,0)
    accou=open("account.txt","r")
    accou=accou.read()
    accou=accou.split("\n")
    global ids
    global name
    for i in accou:
        try:
            lo=i.split(",")
            if(lo[1]==l1):
                c1=1
                ids=lo[1]
                name=lo[0]
                if(lo[3]==l2):
                    c2=1
                    break
        except:
            x=0
    if(c1==0):
        os.system("cls")
        print("  your have no account in 'NITISH STORE'\n  Suggest : open a new account")
        first()
    if(c1==1 and c2==0):
        os.system("cls")
        print("  you enter rong password...\n  login agen--")
        login()
    os.system("cls")
    return 0
    
def newacc():
    print("\n\t _ _ Open New Account _ _")
    i1=input("Enter your Full Name : ")
    i2=input("Enter your Phone no. : ")
    i3=input("Enter e-mail Id : ")
    i4=input("Enter 8 to 16 digit Password : ")
    (c2,c3,c4)=(0,0,0)
    print()
    
    try:
        int(i2)
        if(len(i2)==10):
           c2=1
        else:
            print("your Phone no. --> not valid ")
    except:
        c2=0
        print("your Phone no. --> not valid ")
        
    if("@" in i3):
        c3=1
        em=i3
        em=em.split(".")
        elib=["com","in","gov","org"]
        if(em[len(em)-1] not in elib):
            c3=0
            print("your e-mail Id --> not valid")
    else:
        print("your e-mail Id --> not valid")
    if len(i4)>=8 and len(i4)<=16:
        c4=1
    else:
        print("your Password --> not valid")
    if(c2==0 or c3==0 or c4==0):
        print("Re-enter data agen ---")
        newacc()
    else:
        accou=open("account.txt","r")
        accou=accou.read()
        accou=accou.split("\n")
        al=0
        for i in accou:
            try:
                lo=i.split(",")
                if(lo[1]==i2):
                    al=1
                    break
            except:
                x=0
        if(al==1):
            os.system("cls")
            print("  alrady have this account... now login")
            return 0
        else:
            accou=open("account.txt","a")
            accou.write(i1+","+i2+","+i3+","+i4+"\n")
            accou.close()
            os.system("cls")
            print("Done ... you account is open")
            return 0    
        
def first():
    print("\n\n\t*** _ _ _ NITISh STORE _ _ _ _ ***")
    print("\n  1. Open New Account\t2. Login Account")
    a=input("\n Enter your choice : ")
    if(a!='1' and a!='2'):
        os.system("cls")
        print("  Rong input...\n  Suggest : choice 1 or 2 no. option")
        first()
    else:
        if(a=='1'):
            os.system("cls")
            newacc()
        login()
        return 0

def home():
    print("\n\n\t*** _ _ _ HOME PAGE _ _ _ _ ***")
    print("\n  hi,"+name,"\n\n\t1.buy prodact \t2.order details")
    ch=input("Enter your choice : ")
    if(ch=='1'):
        search()
    elif(ch=='2'):
        orde()
    else:
        os.system("cls")
        print("  Rong input...\n  Suggest : choice 1 or 2 no. option")
        return 0
    return 0

def search():
    print("\n\n\t*** _ _ _ SEARCHING PAGE _ _ _ _ ***")
    print("\nIn store --->  1.Phone   2.Laptop")
    ch=input("Enter your choice : ")
    if(ch!='1' and ch!='2'):
        search()
    else:
        ch=int(ch)-1
        item=open("item.txt",'r')
        item=item.read()
        item=item.split("\n")
        item.remove('')
        icat=[]
        im=[]
        for i in item:
            v=i.split("=")
            icat.append(v[0])
            im.append(v[1])
        for i in range(len(item)):
            im[i]=im[i].split(";")
        print("\n\n\t*** _ _ _",icat[ch],"PAGE _ _ _ _ ***")
        cou=1
        for i in im[ch]:
            v=i.split(",")
            print("  ",cou,v[0],"\t\tRs.",v[1])
            cou+=1
        ich=input("\n which item are you want to buy.Enter no : ")
        try:
            ich=int(ich)-1
            im[ch][ich]=im[ch][ich].split(",")
            print("  ",im[ch][ich][0],"--->  Rs.",im[ch][ich][1])
            cpor=input("have you a promo code (yes/no) : ")
            if(cpor.upper()=='YES' or cpor.upper()=='Y'):
                pd=promo()
                print("you gat Rs.",pd,"off using promocode")
                buy(im[ch][ich][0],(im[ch][ich][1])-pd)
            else:
                buy(im[ch][ich][0],im[ch][ich][1])
        except:
            print("yes")
            search()
    return 0
def buy(itma,itrs):
    ch=input("are you sure.you buy this item (yes/no) : ")
    if(ch.upper()=='NO' or ch.upper()=='N'):
        return 0
    else:
        ode=open("oder.txt","a")
        ode.write(ids+','+itma+','+itrs)
        ode.close()
    return 0
def promo():
    pro=['NSTO2020TT','NITISH44HG','STOREN50CV','NAMS2020B','FIRST50A','NITMAS24']
    pco=input("Enter promo code : ")
    if(pco not in pro):
        print("This promo code is not valid")
        return 0
    return pro.index(pco)*100
def orde():
    print("\n\n\t*** _ _ _ oder details PAGE _ _ _ _ ***")
    ode=open("oder.txt","r")
    ode=ode.read()
    ode=ode.split("\n")
    try:
        ode.remove('')
    except:
        x=0
    if(len(ode)==0):
        print("NULL")
        return 0
    for i in ode:
        c=i.split(",")
        if(c[0]==ids):
            print("  ",c[1],"--->",c[2])
    return 0


first()
name=name.split(" ")
name=name[0]
name=(name[0].upper())+name[1:]
while(True):
    os.system("cls")
    home()


    
